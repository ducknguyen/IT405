package net.greenrivertech.dnguyen.guessinggame;

/*
Duck Nguyen
October 12th, 2017
GuessingActivity
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class GuessingActivity extends AppCompatActivity {
    // key for intent
    public static final String COUNT_CHOICES = "net.greenrivertech.dnguyen.guessinggame";

    // private field
    private EditText guessNumber;
    private String userInput;
    private int guessCount;
    private int guess;
    private int targetNumber;
    private int bound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guessing);

        // Get the intent that started this activity and extract the string
        Intent intent = getIntent();
        userInput = intent.getStringExtra(LandingActivity.USER_INPUT);

        // Display in textview
        TextView boundText = (TextView) findViewById(R.id.boundText);

        // userInput should be 20 if user didn't enter a number in LandingActivity
        boundText.setText("Guess a number between 1 and " + userInput);
        targetNumber = generateNumber(userInput);

        // to get the max bound
        try {
            bound  = Integer.parseInt(userInput);
        } catch (NumberFormatException e) {
            displayToast("Something's wrong... please try again");
        }

        // reset guessCount
        guessCount = 0;
    }

    /**
     * @param view - the view object that was clicked
     *
     * */
    public void guessGame (View view) {

        guessNumber = (EditText) findViewById(R.id.guessNumber);
        String userGuess = guessNumber.getText().toString();


        if ( userGuess.isEmpty() ) {
            displayToast("Please enter a number");
        }

        // big else here
        else {

            try {
                guess = Integer.parseInt(userGuess);
            } catch (NumberFormatException e) {
                displayToast("Something's wrong... please try again");
            }
            //displayToast(Integer.toString(bound));

            // building message string and simple error check
            StringBuilder msg = new StringBuilder("Your guess is ");
            Boolean error = true;

            // boundaries check
            if ( (guess < 0) || (guess > bound) ) {
                guessCount++;
                msg.append("way off the boundary, try again!");
            }

            else if (guess > targetNumber) {
                guessCount++;
                msg.append("too high "); //+ guess + " -- " + targetNumber + " -- " + guessCount);

            }
            else if (guess < targetNumber) {
                guessCount++;
                msg.append("too low "); //+ guess + " -- " + targetNumber + " -- " + guessCount);
            }

            else {
                guessCount++;
                error = false;
                msg.append("correct! "); //+ guess + " -- " + targetNumber + " -- " + guessCount);
            }

            displayToast(msg.toString());

            // passing data to next activity
            if (!error) {
                Intent intent = new Intent(this, ResultsActivity.class);
                String count = Integer.toString(guessCount);
                intent.putExtra(COUNT_CHOICES, count);
                startActivity(intent);
            }
        }
    }

    /**
     * @param userInput - userInput to convert to target number
     *                  as well as determining max bound
     *
     * */
    private int generateNumber (String userInput) {
        // n is default value
        int n = 20;
        int target;

        // n changes if user provided input in LandingActivity
        try {
            n  = Integer.parseInt(userInput);
        } catch (NumberFormatException e) {
            displayToast("Something's wrong... please try again");
        }

        target = (int)(Math.random() * (n + 1));
        return target;
    }

    /**
     * @param message - message to be displayed by Toast
     *
     * */
    public void displayToast (String message) {
        Toast.makeText(GuessingActivity.this, message, Toast.LENGTH_LONG).show();
    }
}