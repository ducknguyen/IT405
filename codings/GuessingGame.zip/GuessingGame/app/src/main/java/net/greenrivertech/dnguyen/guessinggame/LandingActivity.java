package net.greenrivertech.dnguyen.guessinggame;

/*
Duck Nguyen
October 12th, 2017
LandingActivity
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LandingActivity extends AppCompatActivity {
    // key for intent
    public static final String USER_INPUT = "net.greenrivertech.dnguyen.guessinggame";

    // private field
    private EditText userInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing);
    }

    /**
     * @param view - the view object that was clicked
     *
     * */

    public void startGame (View view) {

        Intent intent = new Intent(this, GuessingActivity.class);
        userInput = (EditText) findViewById(R.id.userInput);
        String inputText = userInput.getText().toString();

        // set default boundMax
        intent.putExtra(USER_INPUT, "20");

        // user's choice of boundMax
        if ( !(inputText.isEmpty()) ) {
            intent.putExtra(USER_INPUT, inputText);
        }

        startActivity(intent);
    }
}