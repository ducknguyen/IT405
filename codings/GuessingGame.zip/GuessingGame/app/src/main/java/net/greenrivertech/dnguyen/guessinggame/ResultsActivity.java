package net.greenrivertech.dnguyen.guessinggame;

/*
Duck Nguyen
October 12th, 2017
ResultsActivity
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ResultsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        // Get the intent that started this activity and extract the string
        Intent intent = getIntent();
        String guesses = intent.getStringExtra(GuessingActivity.COUNT_CHOICES);

        // Display number of guesses user's taken
        TextView guessCount = (TextView) findViewById(R.id.guessCount);
        guessCount.setText("It took you " + guesses + " guess");
    }

    /**
     * @param view - the view object that was clicked
     *
     * */
    public void restartGame (View view) {
        Intent intent = new Intent(this, LandingActivity.class);
        startActivity(intent);
    }
}