package co.miniforge.corey.mediatracker;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;
import org.w3c.dom.Text;

import co.miniforge.corey.mediatracker.media_recycler.MediaViewHolder;
import co.miniforge.corey.mediatracker.model.MediaItem;
import co.miniforge.corey.mediatracker.ui_helpers.ThemeHelper;

/**
 * This activity will display the contents of a media item and allow the user to update the contents
 * of the item. When the user clicks the save button, the activity should create an intent that goes
 * back to MyListActivity and puts the MediaItem into the intent (If you are stuck on that, read through
 * the code in MyListActivity)
 */

public class MediaDetailActivity extends AppCompatActivity {
    /**
     * Added by Duck on 10/26/17
     */
    Context context;
    View currentView;

    EditText mediaTitle;
    EditText mediaDescription;
    EditText mediaUrl;

    FloatingActionButton mediaCamera;
    FloatingActionButton themeSetting;
    Button mediaSave;

    JSONObject jsonData;
    MediaItem mediaItem;
    ThemeHelper themeHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media_detail);

        locateViews();
        themeHelper = new ThemeHelper(context);

        getData();
        bindData();

        bindFunctionality();
    }

    /**
     * Locate all necessary views
     */
    void locateViews() {
        context = getApplicationContext();

        // Text fields
        mediaTitle = (EditText) findViewById(R.id.mediaDetailTitle);
        mediaDescription = (EditText) findViewById(R.id.mediaDetailDescription);
        mediaUrl = (EditText) findViewById(R.id.mediaDetailUrl);

        // Buttons
        mediaCamera = (FloatingActionButton) findViewById(R.id.mediaCamera);
        themeSetting = (FloatingActionButton) findViewById(R.id.themeSetting);
        mediaSave = (Button) findViewById(R.id.mediaDetailSave);

        // Get the
        currentView = findViewById(R.id.media_detail_view);
    }

    /**
     * Get json data from intent
     */
    void getData() {
        if(getIntent().hasExtra(MediaViewHolder.data)) {
            String mediaStringJSON = getIntent().getStringExtra(MediaViewHolder.data);

            try {
                jsonData = new JSONObject((mediaStringJSON));
                mediaItem = new MediaItem(jsonData);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Binding data to appropriate fields
     */
    void bindData(){
        mediaTitle.setText((mediaItem.title));
        mediaDescription.setText((mediaItem.description));
        mediaUrl.setText((mediaItem.url));
    }

    /**
     * Start intent to next activity base on user's choice
     */
    void bindFunctionality() {

        // Take picture button
        // starting code for letting user take picture
        // will work on it again later if there's time
        mediaCamera.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(takePictureIntent, 100);
            }
        });

        // Change theme
        themeSetting.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                //this odd looking piece of code that Corey gave
                themeHelper.enableDarkTheme(!themeHelper.darkThemeEnabled());

                themeHelper.themeTextView(mediaTitle, mediaDescription, mediaUrl);
                themeHelper.themeBackground(currentView);

            }
        });

        // Save Button
        mediaSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mediaItem.title = mediaTitle.getText().toString();
                mediaItem.description = mediaDescription.getText().toString();
                mediaItem.url = mediaUrl.getText().toString();

                // prompt save confirmation
                prompConfirmation();

            }

            /**
             * prompt user with a dialog confirm saving
             */
            void prompConfirmation() {
                AlertDialog.Builder builder = new AlertDialog.Builder(MediaDetailActivity.this);
                builder.setTitle("Save Changes").setMessage("Save changes?")

                    .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(getApplicationContext(), MyListActivity.class);
                            intent.putExtra(MyListActivity.mediaExtra, mediaItem.toJson().toString());
                            startActivity(intent);
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });

                //create confirmation dialog
                AlertDialog alertDialog = builder.create();

                alertDialog.show();
            }
        });

    }
}