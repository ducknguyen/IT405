package co.miniforge.corey.mediatracker;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import co.miniforge.corey.mediatracker.ui_helpers.ThemeHelper;

public class SettingsActivity extends AppCompatActivity {
    ThemeHelper themeHelper;

    TextView currentTheme;
    Button settingButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        locateViews();
        handleIntent();

        themeHelper = new ThemeHelper(getApplicationContext());
    }

    void locateViews(){
        currentTheme = (TextView)findViewById(R.id.currentTheme);
        settingButton = (Button) findViewById(R.id.settingButton);

    }

    void handleIntent(){
        Intent intent = getIntent();

    }

    void bindFunctionality() {
        settingButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                themeHelper.enableDarkTheme(!themeHelper.darkThemeEnabled());
            }
        });
    }

}
