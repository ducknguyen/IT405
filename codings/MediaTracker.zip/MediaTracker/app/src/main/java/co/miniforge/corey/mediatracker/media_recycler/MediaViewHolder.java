package co.miniforge.corey.mediatracker.media_recycler;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import co.miniforge.corey.mediatracker.MediaDetailActivity;
import co.miniforge.corey.mediatracker.MediaItemDetailActivity;
import co.miniforge.corey.mediatracker.MyListActivity;
import co.miniforge.corey.mediatracker.R;
import co.miniforge.corey.mediatracker.model.MediaItem;

import static co.miniforge.corey.mediatracker.MyListActivity.mediaExtra;

/**
 * Created by corey on 10/15/17.
 */

public class MediaViewHolder extends RecyclerView.ViewHolder {
    public static String data;

    TextView mediaName;
    TextView mediaDescription;
    TextView mediaUrl;
    View inflated;

    Context context;

    public MediaViewHolder(View itemView) {
        super(itemView);

        locateViews(itemView);
    }

     void locateViews(View itemView) {
        inflated = itemView;
        context = itemView.getContext();

        mediaName = itemView.findViewById(R.id.mediaName);
        mediaDescription = itemView.findViewById(R.id.mediaDescription);
        mediaUrl = itemView.findViewById(R.id.mediaUrl);
    }

    public void bindData(final MediaItem mediaItem){
        this.mediaName.setText(mediaItem.title);
        this.mediaDescription.setText(mediaItem.description);
        this.mediaUrl.setText(mediaItem.url);


        inflated.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //TODO: Create a new activity with this object's data
                //Hint: mediaItem.toJson().toString() && context.startActivity);

                // code added by Duck
                Intent intent = new Intent(context, MediaDetailActivity.class);
                data = mediaItem.toJson().toString();
                intent.putExtra(data, data);
                context.startActivity(intent);
            }
        });

        // long click for deleting the button
        // code added by Duck
        inflated.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

            //alert dialog for delete confirmation
            AlertDialog.Builder builder = new AlertDialog.Builder(context);

            //set title
            builder.setTitle("Pernamently delete this item?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ((MyListActivity)context).deleteMediaItem(mediaItem);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
            //create confirmation dialog
            AlertDialog alertDialog = builder.create();

            alertDialog.show();
            return true;
            }
        });
    }
}
