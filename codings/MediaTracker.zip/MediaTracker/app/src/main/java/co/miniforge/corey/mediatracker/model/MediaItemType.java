package co.miniforge.corey.mediatracker.model;

import java.io.Serializable;
/**
 * Created by duck on 11/11/17.
 */

public enum MediaItemType {
    Generic,
    Movie,
    TV
}
