package co.miniforge.corey.mediatracker.ui_helpers;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import co.miniforge.corey.mediatracker.model.MediaItem;

/**
 * Created by duck on 11/18/17.
 */

public class MediaItemSortHelper {

    /**
     * Sorts the MediaItems by name
     *
     * @param items - a list containg the MediaItems to be sorted
     * @return a list of sorted MediaItem
     */
    public static List<MediaItem> sortByName(List<MediaItem> items) {

        // list to hold all sorted Media Items
        List<MediaItem> newList = new LinkedList<>();

        // initialize a map and array to store the values of the title & item
        HashMap<String, MediaItem> map = new HashMap<>();
        String[] titles = new String[items.size()];

        for (int i = 0; i < items.size(); i++){

            // get the current item
            MediaItem item = items.get(i);

            // put current item in map: key - title, item - value
            // put the current item title in titles[]
            map.put(item.title, item);
            titles[i] = (item.title);

        }

        // sort the array
        Arrays.sort(titles);

        // take each element in titles[] as a key
        // extract value from map using that key and add to newList
        for(String s : titles) {
            newList.add(map.get(s));
        }

        // return sorted list
        return newList;
    }



    public static List<MediaItem> sortByType(List<MediaItem> items) {

        MediaItem[] itemArray = new MediaItem[items.size()];
        Arrays.sort(itemArray, new Comparator<MediaItem>() {
            @Override
            public int compare(MediaItem mediaItem, MediaItem t1) {
                return mediaItem.type.compareTo(t1.type);
            }
        });



        return new LinkedList<>(Arrays.asList(itemArray));
    }

}

