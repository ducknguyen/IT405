package co.miniforge.corey.mediatracker.ui_helpers;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import co.miniforge.corey.mediatracker.R;

/**
 * Created by duck on 11/17/17.
 */

public class ThemeHelper {
    //https://developer.android.com/reference/android/content/SharedPreferences.html
    private SharedPreferences sharedPref;

    // private int associated with each theme color added in colors.xml
    private int themeDarkText, themeDarkContainer,
                themeDarkBg, themeLightText,
                themeLightContainer, themeLightBg;

    /**
     * Constructor for ThemeHelper
     *
     * @param context
     */
    public ThemeHelper(Context context) {
        try {

            themeDarkText = ContextCompat.getColor(context, R.color.themeDarkText);
            themeDarkContainer = ContextCompat.getColor(context, R.color.themeDarkContainer);
            themeDarkBg = ContextCompat.getColor(context, R.color.themeDarkBg);

            themeLightText = ContextCompat.getColor(context, R.color.themeLightText);
            themeLightContainer = ContextCompat.getColor(context, R.color.themeLightContainer);
            themeLightBg = ContextCompat.getColor(context, R.color.themeLightBg);

            // store a simple key/value pair for current theme
            sharedPref = context.getSharedPreferences("theme", 0);

        } catch (Exception e){
            Log.e("toColorThemeError", String.format("There was an error: %s", e.getMessage()));
        }


    }


    public boolean darkThemeEnabled() {

        // getBoolean(String key, bool devValue)
        // return false if theme not in use
        return sharedPref.getBoolean("darkTheme", false);
    }

    public void enableDarkTheme(boolean enabled) {

        //https://developer.android.com/reference/android/content/SharedPreferences.Editor.html
        // set a boolean value in the preferences editor and apply it
        sharedPref.edit().putBoolean("darkTheme", enabled).apply();
    }

    public void themeTextView(TextView...textViews) {
        boolean dark = darkThemeEnabled();

        // for each textView
        // if dark is true -> set color themeDarkText
        // else -> themeLightText
        for (TextView textView : textViews) {
            textView.setTextColor(dark ? themeDarkText : themeLightText);
        }
    }

    public void themeImageContainer(View...containers) {
        boolean dark = darkThemeEnabled();

        // similar operation as themeTextView but for view containers
        // change background color of view's container
        for (View view : containers) {
            view.setBackgroundColor(dark ? themeDarkContainer : themeLightContainer);
        }
    }
    public void themeBackground(View rootview) {
        boolean dark = darkThemeEnabled();

        // similar operation as themeTextView but for rootView
        rootview.setBackgroundColor(dark ? themeDarkBg : themeLightBg);
    }


}
